package Server;

import Implementation.Implementation;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class AtwaterServer {
    public AtwaterServer() {
    }

    private static final int NUM_THREADS = 2;

    public static void main(String[] args) {


        try {
            Implementation obj = new Implementation();
            obj.portsToPing= new int[]{5098, 5097};
            obj.movieData.put("AVATAR", new HashMap<String, Integer>());
            obj.movieData.put("TITANIC", new HashMap<String, Integer>());
            obj.movieData.put("AVENGERS", new HashMap<String, Integer>());
            obj.movieData.get("AVATAR").put("ATWM030223", 40);
            obj.movieData.get("AVENGERS").put("ATWM030223", 40);
            obj.movieData.get("TITANIC").put("ATWM030223", 40);
            Registry registry = LocateRegistry.createRegistry(3001);
            Naming.rebind("Atwater", obj);
            System.out.println("Atwater server ready");

        } catch (Exception e) {
            System.out.println(e);
        }
    }

}
